import Model.*;

public class InitializeBoard {

	private Board board;

	public InitializeBoard() {
		// TODO - implement InitializeBoard.InitializeBoard
		throw new UnsupportedOperationException();
	}

	public Board getBoard() {
		return this.board;
	}

	public void addChess() {
		// TODO - implement InitializeBoard.addChess
		throw new UnsupportedOperationException();
	}

}