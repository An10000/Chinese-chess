import Model.*;

public class Cannon extends Chess implements Moveable {

	/**
	 * 
	 * @param destination
	 * @param board
	 */
	public void move(Location destination, Board board) {
		// TODO - implement Cannon.move
		throw new UnsupportedOperationException();
	}

}