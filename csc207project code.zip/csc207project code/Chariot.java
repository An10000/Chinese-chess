import Model.*;

public class Chariot extends Chess implements Moveable {

	/**
	 * 
	 * @param destination
	 * @param board
	 */
	public void move(Location destination, Board board) {
		// TODO - implement Chariot.move
		throw new UnsupportedOperationException();
	}

}