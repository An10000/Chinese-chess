package View;

public class ChessGame {

	private String mode;

	/**
	 * 
	 * @param mode
	 */
	public void startGame(String mode) {
		// TODO - implement ChessGame.startGame
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param mode
	 */
	public void ChessGame(String mode) {
		// TODO - implement ChessGame.ChessGame
		throw new UnsupportedOperationException();
	}

}