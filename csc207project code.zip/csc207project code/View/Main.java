package View;

public class Main {

	/**
	 * 
	 * @param String
	 */
	public static void main(int[] String) {
		// TODO - implement Main.main
		throw new UnsupportedOperationException();
	}

}