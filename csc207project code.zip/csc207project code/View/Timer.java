package View;

public class Timer {

	private int roundTime;
	private Viewer viewer;

	public void countDown() {
		// TODO - implement Timer.countDown
		throw new UnsupportedOperationException();
	}

}