import Model.*;

public class Elephant extends Chess implements Moveable {

	/**
	 * 
	 * @param destination
	 * @param board
	 */
	public void move(Location destination, Board board) {
		// TODO - implement Elephant.move
		throw new UnsupportedOperationException();
	}

}