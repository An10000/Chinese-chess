import Model.*;

public class Advisor extends Chess implements Moveable {

	/**
	 * 
	 * @param destination
	 * @param board
	 */
	public void move(Location destination, Board board) {
		// TODO - implement Advisor.move
		throw new UnsupportedOperationException();
	}

}