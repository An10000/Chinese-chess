package Model;

public class Player {

	private String faction;

	public String getFaction() {
		return this.faction;
	}

}