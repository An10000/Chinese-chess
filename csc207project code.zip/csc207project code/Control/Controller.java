package Control;

import Model.*;
import View.*;

public class Controller {

	private Player[] players;
	private String mode;

	/**
	 * 
	 * @param chess
	 * @param destination
	 */
	public boolean moveRequest(Chess chess, Location destination) {
		// TODO - implement Controller.moveRequest
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param board
	 * @param players
	 * @param mode
	 * @param viewer
	 * @param scorer
	 */
	public Controller(Board board, Player[] players, String mode, Viewer viewer, Scorer scorer) {
		// TODO - implement Controller.Controller
		throw new UnsupportedOperationException();
	}

}