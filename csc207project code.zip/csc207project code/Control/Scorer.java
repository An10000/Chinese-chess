package Control;

import Model.*;

public class Scorer {

	private HashMap<String, Integer> scoreBoard;

	/**
	 * 
	 * @param faction
	 */
	public int getFactionScore(String faction) {
		// TODO - implement Scorer.getFactionScore
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param faction
	 * @param killed
	 */
	public void addScore(String faction, Chess killed) {
		// TODO - implement Scorer.addScore
		throw new UnsupportedOperationException();
	}

}