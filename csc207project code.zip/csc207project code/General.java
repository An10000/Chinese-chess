import Model.*;

public class General extends Chess implements Moveable {

	/**
	 * 
	 * @param destination
	 * @param board
	 */
	public void move(Location destination, Board board) {
		// TODO - implement General.move
		throw new UnsupportedOperationException();
	}

}